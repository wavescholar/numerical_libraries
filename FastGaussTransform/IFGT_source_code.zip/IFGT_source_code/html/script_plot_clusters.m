%% plot_clusters
% Plots the output of k-center clustering
%% Syntax
%  plot_clusters(N,d,X,K,ClusterIndex,ClusterCenter)
%% Description
%%
%
