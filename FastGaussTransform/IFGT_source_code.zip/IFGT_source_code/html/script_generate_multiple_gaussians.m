%% generate_multiple_gaussians
% Generates N samples in d dimensions  from G gaussians
%% Syntax
%  [X]=generate_multiple_gaussians(N,G,m,v,d)
%% Description
%%
% m -- dxG mean
%%
% v  -- 1xG variance
%%
%
