%% Equations
%
% $$\hat{G}(y_j)$$
%
%
% $$G(y_j)=\sum_{i=1}^{N} q_i e^{\|x_i-y_j\|^2/h^2},\:\:j=1...M$$
%
%
% $$|\hat{G}(y_j)-G(y_j)| \leq Q \epsilon$$
%
%
% $$Q=\sum_{i=1}^{N}q_i$$
%
%
% $$\hat{G}(y_j)$$
%
%
% $$|\hat{G}(y_j)-G(y_j)| \leq Q \epsilon$$
%
%
% $$Q=\sum_{i=1}^{N}q_i$$
%
