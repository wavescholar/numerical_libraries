%% Equations
%
% $$G(y_j)=\sum_{i=1}^{N} q_i e^{\|x_i-y_j\|^2/h^2},\:\:j=1...M$$
%
