%% IFGT
%%
%% Syntax
%  [G]=IFGT(d,N,M,X,h,q,Y,epsil)
%% Description
% Fast computation of the Gauss Transform.
%%
% Computes and approximation $$\hat{G}(y_j)$$ to $$G(y_j)=\sum_{i=1}^{N} q_i
% e^{\|x_i-y_j\|^2/h^2},\:\:j=1...M$$  such that
% $$|\hat{G}(y_j)-G(y_j)| \leq Q \epsilon$$ , where
% $$Q=\sum_{i=1}^{N}q_i$$.
%
% C++ Implementation.
%%
%%
%% Input
%%
%%
% * d                 --> data dimensionality.
% * N                 --> number of source points.
% * M                 --> number of target points.
% * X                 --> d x N matrix of N source points in d dimensions.
% * h                 --> source bandwidth or scale.
% * q                 --> 1 x N vector of the source strengths.
% * Y                 --> d x M matrix of M target points in d dimensions.
% * epsil         --> desired error
%%
%% Ouput
%%
%%
% * G                --> 1 x M vector of the Gauss Transform evaluated at  each target point.
%%
%% Signature
%%
%%
% * *Author:* Vikas Chandrakant Raykar
% * *E-Mail:* vikas@cs.umd.edu
% * *Date:*  08 July 2005
%%
%% See also
%%
% ImprovedFastGaussTransformChooseParameters,  ImprovedFastGaussTransformChooseTruncationNumber,  KCenterClustering,  ImprovedFastGaussTransform
%%
%%
%%
%
