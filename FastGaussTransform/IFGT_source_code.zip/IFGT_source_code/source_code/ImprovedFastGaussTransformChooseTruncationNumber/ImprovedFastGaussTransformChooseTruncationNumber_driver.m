d=2
h=0.3
epsilon=1e-6
rx=0.1

[p_max]=ImprovedFastGaussTransformChooseTruncationNumber(d,h,epsilon,rx)

